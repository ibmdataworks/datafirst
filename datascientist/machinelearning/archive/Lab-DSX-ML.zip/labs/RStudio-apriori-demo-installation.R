#installing the packages for RStudio demo

#To install graphNEL:
source("http://bioconductor.org/biocLite.R")
biocLite("graph")

#To install NCIgraph:
biocLite("NCIgraph")

#Installing RGraphviz:
biocLite("Rgraphviz")

#Installing arulesViz
install.packages("arulesViz")
